//
//  KeychainWrapper.swift
//  TouchMeIn
//
//  Created by Tim Mitra on 11/23/14.
//  Copyright (c) 2014 iT Guy Technologies. All rights reserved.
//

import UIKit
import Security

class KeychainWrapper {
  
  
}
